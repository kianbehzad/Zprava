class TextMessage(models.Model):
    publisher = models.ForeignKey(Users,
     related_name="published_text_messages",
      null=True, on_delete=models.CASCADE)
    subscriber = models.ForeignKey(Users,
     related_name="subscribed_text_messages",
      null=True, on_delete=models.CASCADE)
    chat = models.ForeignKey(Chat,
     related_name="chat_text_messages",
      null=True, on_delete=models.CASCADE)
    is_seen = models.BooleanField(default=False)
    datetime = models.CharField(max_length=50, null=True)
    text = models.CharField(max_length=1000)
    type = models.CharField(max_length=50, null=True)#TEXT-PHOTO-AUDIO-VIDEO
    def __str__(self):
        return self.publisher.__str__() 
        + ' - ' + self.subscriber.__str__() 
        + ' : ' + self.text[0:20] + '...'